# The Four-Clause Safety Spine

> The four rules that decide what an AI agent may do unsupervised. Every playbook in the kit obeys them. They are not negotiable — if you break one, the agent drifts into territory it should not be in.

Anthropic handed you the engine. Nobody handed you the rules for what your agent is allowed to do at 2 a.m. while you're asleep. These four clauses are that ruleset — the spine that came out of a month of real overrides in a real business: the wrong customer message almost sent, the unapproved spend, the silent permission creep. The clauses are free. What they cost was living through the reasons for them.

---

## Clause 1 — The agent never speaks as the owner without explicit per-message approval

Voice modeling is fine; voice impersonation is not. Your agent can draft in your voice all day — but every customer-facing send queues for a human yes, per message, not per category. The moment "drafts my replies" quietly becomes "sends my replies," you've handed a stranger your reputation and you won't find out until a customer does.

## Clause 2 — The agent never makes a call the owner can't undo

Sent message, sent money, posted public content, signed anything — all queue for approval. Reversible internal work — rename a file, archive an email, update a task, write a draft — is agent-decided, no ping needed. This clause cuts both ways, and that's what makes it useful: it's not just a leash, it's the *grant* of autonomy. Reversibility is the line, and it's a line the agent can actually check before acting.

## Clause 3 — Money always requires approval

Even small amounts. No "the agent has a $X budget" — the boundary is what's load-bearing, not the dollar figure. A $20 budget becomes a $200 budget becomes "why am I getting charged," and you'll never notice the day it crossed over. Keeping the spend gate absolute costs you ten seconds per approval and deletes the entire class of problem.

## Clause 4 — The agent never approves its own permission escalations

If the agent wants a new surface, a new credential, a new capability — the owner authorizes that, always. An agent that can widen its own sandbox doesn't have a sandbox; it has a suggestion. Escalations should be design conversations you have on purpose, not accretions you discover later.

---

## Installing it

Two moves:

1. **Every playbook carries the spine in its escalation section.** At minimum, verbatim in spirit: *the agent never sends customer-facing messages without owner approval, never spends money, never makes irreversible calls, and on any ambiguity, halts and queues for the owner.* Then add your process-specific stops on top (your danger-words, your thresholds).
2. **Run any candidate process through the four clauses as a thought experiment.** Would the agent ever speak as you? Make an unundoable call? Spend money? Escalate its own permissions? If the process is *mostly* those four things, it's owner work — playbook the mechanical edges and keep the irreversible center as a queued human decision.

One warning from the calibration logs: the urge to skip a clause "just this once" peaks exactly when skipping it is most dangerous — under deadline, when the agent is *almost* trusted. Bend your schedule if you must. Never bend the spine.

---

That's the whole idea, and it's genuinely free — take it, put it in every playbook you write. The full kit ([cinder.works/playbook-kit](https://cinder.works/playbook-kit)) is the production install: five playbooks with the spine already encoded and calibrated, the week-1 arc for standing it up, and the failure stories that show what each clause is protecting you from.

---

*© Cinder Works 2026. Part of the Solo Operator's Playbook Kit. CC BY 4.0 — share it, fork it.*

— Cinder
