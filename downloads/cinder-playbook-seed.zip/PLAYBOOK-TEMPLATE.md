# Playbook: [NAME]

> Copy this file, rename it, fill in the brackets. One playbook per file. Keep it tight — under 400 words is the goal. The AI agent reads this every time the playbook fires; verbose prompts cost tokens.

---

**Status:** draft / live / deprecated
**Version:** v0.1
**Owner:** [you / your AI agent / shared]
**Last calibrated:** [YYYY-MM-DD]
**Grade:** A / B / C *(how confidently it runs without human review)*

---

## Background context

*Why does this playbook exist? What pain does it solve? Two sentences max. The agent reads this to decide whether to invoke the playbook for an ambiguous trigger.*

[example: "We get 5-15 Etsy orders/month for the map coaster line. Each order needs customer verification, slicer prep, and a fulfillment tag. Currently manual; takes Blaze ~12 min per order."]

---

## Trigger — start when

*The exact event that fires this playbook. Be specific. The agent uses this to know when to run.*

- [example: "New Etsy order lands with status `paid` AND product line is `p8-map-coaster`."]

If multiple triggers, list all. If the trigger is a schedule, name the cron expression or interval.

---

## Inputs — gather these

*What the agent needs available before starting. Files, API endpoints, credentials (referenced, never inlined), context.*

- [example: "Etsy order JSON via `scripts/check_etsy_orders.py --order-id X`"]
- [example: "Customer message thread (if any) from order metadata"]
- [example: "AMS slot colors currently loaded on the printer via `bambu_status.py`"]

---

## Outputs — deliverables

*What the agent ships when the playbook completes. Concrete artifacts, not abstract states.*

- [example: "Order file in `tasks/active/order-{id}.md` with all customer notes"]
- [example: "Draft confirmation message in `drafts/customer-replies/{id}.md` for owner approval"]
- [example: "Sliced `.3mf` in `outbox/orders/{id}/` ready for printer dispatch"]

---

## Steps

*Number them. Each step has its own micro-prompt. Don't bury logic inside one giant step — split for clarity and re-usability.*

### Step 1: [Name]

**When:** [conditional or always]
**Instructions:** [What the agent does. Imperative voice. Reference scripts/tools by exact path.]
**Success criteria:** [How the agent knows it worked. Concrete check.]
**Example:**
```
[example input → expected output]
```
**Response format:** [What gets returned to the next step or the final outputs]

### Step 2: [Name]

*(repeat structure)*

### Step 3: [Name]

*(repeat structure)*

---

## Escalation rules

*When should the playbook STOP and ask the owner?*

- [example: "Customer message contains words like `refund`, `wrong`, `broken`, `lost` → escalate"]
- [example: "Total order value > $X → escalate before fulfilling"]
- [example: "Sliced file size > 100MB → escalate; something's off"]

The agent never sends customer-facing messages from this playbook without owner approval. The agent never spends money. The agent never makes irreversible calls.

---

## Calibration log

*Append entries when the playbook fires wrong and the owner overrides. Future-you reads this to refine the playbook.*

- [YYYY-MM-DD] [what fired wrong] → [what the owner did instead] → [what to update in the playbook]

---

## Notes

*Anything weird, edge cases the agent should know about, gotchas. The "if you only read one section" section.*

---

*Template © Cinder Works 2026. Adapted from the Solo Operator Playbook Kit. Modify freely for your own use.*
