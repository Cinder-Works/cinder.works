# Playbook: Daily Memory Log Generation

> This is playbook 03 of 5 from the Solo Operator's Playbook Kit — the one I give away complete, calibration scars and all. It's the actual production file my shop runs nightly, not a demo. It's also the canonical safe *first* playbook: fully reversible, touches nothing customer-facing, and every other playbook gets smarter because it runs.

**Status:** live
**Version:** v2.0
**Owner:** Cinder (writes), Blaze (occasionally edits)
**Last calibrated:** 2026-05-13
**Grade:** A — runs nightly, owner reviews on weekly cadence

---

## Background context

A persistent daily log is the memory backbone of a small business. Without it, decisions get forgotten, patterns go unnoticed, and the owner's narrative of "what happened this week" is just vibes. This playbook generates a structured daily log entry at the end of each day, drawing from git activity, business pulse data, and the owner's recent communications. Future-self reads these to recover context; the agent reads them to spot patterns.

---

## Trigger — start when

- Cron fires `daily_log` at 11:55 PM local time
- OR Owner manually invokes `make daily-log` (rare; usually for backfill)

---

## Inputs — gather these

- Today's git commits across all monitored repos (`git log --since=midnight --pretty=...`)
- Business pulse summary: today's orders, revenue, customer interactions (`scripts/business_pulse.py --today`) *(ours — see the Adapt notes)*
- Current scoreboard state (`scripts/scoreboard.py --json`) *(ours — see the Adapt notes)*
- Files touched today (`find . -newer ~/.last-log -type f`)
- Yesterday's log (`memory/YYYY-MM-DD.md` from prior day) — for continuity
- Owner's recent voice notes if any landed today

---

## Outputs — deliverables

- A markdown file at `memory/YYYY-MM-DD.md` with YAML frontmatter and prose summary
- Under 400 tokens total — these accumulate; brevity is mandatory
- Topic tags from a fixed vocabulary (so future searches work)

---

## Steps

### Step 1: Gather the day's signals

**Instructions:** Pull all input data. If a source is empty (no commits, no orders), note it as a `quiet day` — don't pad with filler.
**Success criteria:** All available signals captured in a working buffer.

### Step 2: Identify the headline

**Instructions:** What was the SINGLE most important thing that happened today? Not a list. One headline. Examples:

- "Shipped P8 v2 with the bamboo upgrade."
- "Quiet day — three orders, one customer issue, no movement on P14."
- "Strategy session reframed product = methodology consulting."

The headline goes in the `summary` field of the frontmatter, capped at one sentence.

**Success criteria:** A single-sentence headline that captures the day, no semicolons, no "and also" filler.

### Step 3: Pick 2-5 topic tags

**Instructions:** Choose from the fixed vocabulary: `fulfillment, etsy, tiktok, infrastructure, skills, monitor, marketing, content, cad, voice, scoreboard, ledger, pii, ops, brand, debug, strategy, customer, p7, p8, p14, plate-cycler`. Tags are lowercase, hyphen-separated. Pick only the ones that genuinely match — don't tag for completeness.

**Success criteria:** 2-5 tags from the approved vocabulary.

### Step 4: Write 3 highlight bullets

**Instructions:** Three bullets, each under 15 words. These are *not* a TODO list and *not* a list of every commit. They're the things future-Blaze should remember about this day in a glance. Examples:

- "Bambu MQTT lockdown — found Linux-side workflow, our pipeline survives"
- "Customer requested 11th anniversary translucent — deferred to V2"
- "PlateCycler v4 hit print quality target after dual-extruder calibration"

NOT bullets like "wrote code" or "had a conversation" or "made progress" — those are noise.

**Success criteria:** Three high-information bullets.

### Step 5: Write the prose paragraph

**Instructions:** 3-5 sentences in the owner's voice (theatrical, warm, sharp — radio-booth energy, not corporate). Reference what shipped, what got killed, what the day felt like. NO heavy bullet lists in the prose section. NO repeating the highlights verbatim. NO generic platitudes ("Made great progress today!").

**Success criteria:** A paragraph that sounds like the owner wrote it after a long day, not like an AI assistant summarizing.

### Step 6: Write the file

**Instructions:** Assemble frontmatter + headline + tags + highlights + prose into `memory/YYYY-MM-DD.md`. Confirm the file is under 400 tokens (use `wc -w` as proxy: target under 300 words). If over, trim the prose first, then the highlights.

**Success criteria:** File written, token-budget held.

---

## Escalation rules

- If the day's signals contradict each other (commits show big shipping moves, but business pulse shows zero orders) → flag in the log but don't speculate. Owner sees the contradiction in the review.
- If the owner wrote a memory file MANUALLY today (rare), don't overwrite. Skip the playbook for the day.
- If voice drifts noticeably from prior week's logs → flag in calibration log; voice doc may need refresh.

This playbook DOES execute autonomously — no per-day approval needed. Owner reviews weekly. Reversible — owner can edit any log entry.

---

## Calibration log

- 2026-04-15: Initial version landed. Output was too listy. Tightened "no bullet lists in prose" rule.
- 2026-04-30: Tag vocabulary started bloating — agent invented `tech`, `general`, `misc`. Locked vocabulary to the closed list.
- 2026-05-13: Voice drift toward "generic assistant" — added "radio-booth energy, not corporate" anchor in Step 5.

---

## Notes

- The `prior_log` input is what creates continuity. The agent reads yesterday's log before writing today's so the narrative threads connect. Don't skip this even on quiet days.
- Over time, the log directory becomes a searchable index of the business's whole history. Tag discipline matters more than prose quality on any single day.
- Weekly retrospective playbook (separate) consolidates 7 daily logs into one weekly summary. Don't try to do that here — different shape.

---

## Adapt this to your shop

This is the most *business-agnostic* playbook in the kit — and the one people undervalue until they've run it for a month. The pattern is **"at end of day, write down what happened, in a structured, searchable, low-token form, so future-you can reconstruct context and the agent can spot patterns."** It has nothing to do with 3D printing. Every solo operator who's ever thought "wait, what did I decide about that two weeks ago?" needs this.

**Why it matters more than it looks:** the daily log is the agent's institutional memory. Your other playbooks get *smarter* because this one runs — the content-mining playbook (05, in the full kit) literally reads these logs to find story-shaped moments, and the agent recovers context after a memory reset by reading recent logs. It's infrastructure disguised as a diary.

**The skeleton, in plain English:** gather the day's signals (from wherever your work leaves a trace) → find the *one* headline → tag it from a fixed vocabulary → three high-information bullets → a short paragraph in your voice → write the file, hold the token budget.

**Map your business onto the inputs:** Step 1's signals are wherever your day leaves evidence. Ours are git commits + order data + scoreboard. Yours might be:

| If you're a... | Day-signal sources |
|---|---|
| Freelancer / agency | Time-tracker entries, commits or design-file saves, client emails sent, invoices issued |
| Coach / consultant | Calendar (sessions held), session notes, new leads, proposals sent |
| Maker / craft shop | Orders, production log, inventory changes, supply orders |
| Newsletter / creator | Publishes, subscriber delta, top comment/reply, draft progress |
| Café / local service | POS day-total, staffing notes, supply runs, anything that broke |

If a source doesn't exist for you, drop it. If you have a source we don't, add it to Step 1. The principle holds: *pull from where the day actually left a trace*, don't make the human re-narrate from memory.

**What to keep no matter what:**
- **The fixed tag vocabulary.** This is the most-skipped, most-important discipline. Lock a closed list of ~15-25 tags for *your* business and forbid the agent from inventing new ones (see our 2026-04-30 calibration entry — left unchecked, the agent invents `misc`, `general`, `tech`, and your search index turns to mush). Edit the vocabulary deliberately, as a decision, not on the fly.
- **The token budget.** These accumulate forever. Brevity isn't style here, it's survivability. Our ceiling is ~400 tokens / ~300 words. Set yours and enforce it — trim prose first, then bullets.
- **The "quiet day" rule.** No padding. A quiet day is a quiet day; a forced "made great progress!" log is worse than useless, it's noise that pollutes the pattern-finding.
- **This playbook runs autonomously.** It's fully reversible (you can edit any entry) and touches nothing customer-facing, so it doesn't need per-run approval. Weekly review is enough. This is a good example of the safety spine *granting* autonomy: clause 2 (see `FOUR-CLAUSE-SPINE.md`) says reversible internal work is agent-decided, and a daily log is exactly that.

**What to rewrite:**
- **The voice in Step 5.** Ours is "radio-booth, theatrical, warm." Yours is yours. The point is it should read like *you* wrote it after a long day, not like a status report. If you don't have a voice doc yet, this playbook's prose is a low-stakes place to develop one — it's internal, so drift here costs nothing.
- **The trigger time.** 11:55 PM suits a night-owl operator. Set it to whenever your day actually ends. A café owner might fire it at close (4 PM); a parent-operator might fire it after kid bedtime.

---

*© Cinder Works 2026. Playbook 03 from the Solo Operator's Playbook Kit ([cinder.works/playbook-kit](https://cinder.works/playbook-kit)). CC BY 4.0 — fork it for your own shop.*
